-- MySQL dump 10.13  Distrib 5.7.40, for Linux (x86_64)
--
-- Host: 47.109.30.93    Database: eSportClub
-- ------------------------------------------------------
-- Server version	5.7.40-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL COMMENT '登录用户名（super_admin固定为admin）',
  `password` varchar(255) NOT NULL COMMENT '密码（加密存储）',
  `role` enum('super_admin','shop_owner','cs','assessor','finance') NOT NULL DEFAULT 'cs' COMMENT '角色',
  `nickname` varchar(50) NOT NULL DEFAULT '' COMMENT '昵称',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1启用 0禁用',
  `is_super` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1=超级管理员（仅admin本人）0=普通管理员',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_role` (`role`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='管理员表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'admin','$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi','super_admin','超级管理员',1,1,'2026-05-23 09:39:48','2026-05-23 09:39:48');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `boss`
--

DROP TABLE IF EXISTS `boss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `boss` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `boss_no` varchar(20) NOT NULL COMMENT '老板编号 BOSSxxxx',
  `nickname` varchar(50) NOT NULL DEFAULT '' COMMENT '老板昵称',
  `gender` enum('male','female') NOT NULL DEFAULT 'male' COMMENT '性别',
  `wechat` varchar(50) NOT NULL DEFAULT '' COMMENT '联系微信',
  `phone` varchar(20) NOT NULL COMMENT '联系手机（登录账号）',
  `password` varchar(255) NOT NULL COMMENT '密码',
  `referrer_type` enum('companion','boss','none') NOT NULL DEFAULT 'none' COMMENT '推荐人类型',
  `referrer_id` bigint(20) DEFAULT NULL COMMENT '推荐人ID',
  `first_recharge_date` date DEFAULT NULL COMMENT '首次充值日期',
  `total_recharge` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '累计充值',
  `total_gift` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '累计赠送',
  `total_consume` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '累计消费',
  `total_locked` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '累计锁定（未结算订单）',
  `balance` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '剩余余额',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1启用 0禁用',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `boss_no` (`boss_no`),
  UNIQUE KEY `phone` (`phone`),
  KEY `idx_phone` (`phone`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='老板表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `boss`
--

LOCK TABLES `boss` WRITE;
/*!40000 ALTER TABLE `boss` DISABLE KEYS */;
INSERT INTO `boss` VALUES (1,'BOSS0001','测试老板','male','','13900139000','$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi','none',NULL,'2026-05-23',0.00,0.00,0.00,0.00,0.00,1,'2026-05-23 10:53:14','2026-05-23 10:53:14');
/*!40000 ALTER TABLE `boss` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `boss_account`
--

DROP TABLE IF EXISTS `boss_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `boss_account` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `boss_id` bigint(20) NOT NULL COMMENT '老板ID',
  `account_type` enum('retail','silver','gold','diamond') NOT NULL DEFAULT 'retail' COMMENT '散户/银卡/金卡/钻石卡',
  `companion_id` bigint(20) DEFAULT NULL COMMENT '存单陪玩（店存时为null）',
  `discount` decimal(5,2) NOT NULL DEFAULT '1.00' COMMENT '折扣率',
  `recharge_total` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '充值合计',
  `gift_total` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '赠送合计',
  `consume_total` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '消费合计',
  `locked_total` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '锁定合计',
  `balance` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '余额合计',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_boss_id` (`boss_id`),
  KEY `idx_account_type` (`account_type`),
  CONSTRAINT `boss_account_ibfk_1` FOREIGN KEY (`boss_id`) REFERENCES `boss` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='老板账户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `boss_account`
--

LOCK TABLES `boss_account` WRITE;
/*!40000 ALTER TABLE `boss_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `boss_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companion`
--

DROP TABLE IF EXISTS `companion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `companion` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `companion_no` varchar(20) NOT NULL COMMENT '陪玩编号 COMPxxxx',
  `nickname` varchar(50) NOT NULL COMMENT '陪玩昵称（禁止重复）',
  `phone` varchar(20) NOT NULL COMMENT '手机号（登录账号）',
  `password` varchar(255) NOT NULL COMMENT '密码',
  `gender` enum('male','female') NOT NULL DEFAULT 'male' COMMENT '性别',
  `wechat` varchar(50) NOT NULL DEFAULT '' COMMENT '微信号',
  `alipay_account` varchar(50) NOT NULL DEFAULT '' COMMENT '支付宝账号',
  `alipay_name` varchar(50) NOT NULL DEFAULT '' COMMENT '支付宝实名',
  `id_card` varchar(30) NOT NULL DEFAULT '' COMMENT '身份证号',
  `status` enum('active','leave','vacation','blacklisted') NOT NULL DEFAULT 'active' COMMENT '在职/离职/请假/黑名单',
  `commission_rate` decimal(5,2) NOT NULL DEFAULT '0.80' COMMENT '陪玩提成率 0.70/0.80/0.90',
  `deposit_setting` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '设置押金 200/300/500',
  `deposit_self` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '自缴押金',
  `deposit_locked` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '单抵押金（已锁定）',
  `order_income` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '订单收入合计',
  `companion_income` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '陪玩收入合计',
  `paid_salary` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '已发放工资',
  `hire_date` date DEFAULT NULL COMMENT '入职日期',
  `games` json DEFAULT NULL COMMENT '可接游戏类别 ["三角洲","瓦","lol"]',
  `experience` enum('none','under1year','over1year') NOT NULL DEFAULT 'none' COMMENT '工作经验',
  `status_audit` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending' COMMENT '审核状态',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `companion_no` (`companion_no`),
  UNIQUE KEY `nickname` (`nickname`),
  UNIQUE KEY `phone` (`phone`),
  KEY `idx_phone` (`phone`),
  KEY `idx_status` (`status`),
  KEY `idx_status_audit` (`status_audit`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='陪玩表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companion`
--

LOCK TABLES `companion` WRITE;
/*!40000 ALTER TABLE `companion` DISABLE KEYS */;
INSERT INTO `companion` VALUES (1,'COMP0001','小陪玩','13800138000','$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi','male','','','','','active',0.70,0.00,0.00,0.00,0.00,0.00,0.00,'2026-05-23',NULL,'none','approved','2026-05-23 10:53:23','2026-05-23 10:53:23');
/*!40000 ALTER TABLE `companion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `complaint`
--

DROP TABLE IF EXISTS `complaint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `complaint` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(30) DEFAULT NULL COMMENT '关联订单编号',
  `companion_id` bigint(20) DEFAULT NULL COMMENT '陪玩ID',
  `boss_id` bigint(20) DEFAULT NULL COMMENT '老板ID',
  `type` enum('complaint','suggestion') NOT NULL DEFAULT 'complaint' COMMENT '投诉/建议',
  `content` text COMMENT '具体内容',
  `screenshot` varchar(255) DEFAULT NULL COMMENT '备注截图',
  `status` enum('pending','processed') NOT NULL DEFAULT 'pending' COMMENT '处理状态',
  `fine_status` enum('fined','not_fined') DEFAULT NULL COMMENT '罚款情况',
  `fine_amount` decimal(10,2) DEFAULT NULL COMMENT '罚款金额',
  `cs_remark` text COMMENT '客服备注',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_order_no` (`order_no`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='售后投诉表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complaint`
--

LOCK TABLES `complaint` WRITE;
/*!40000 ALTER TABLE `complaint` DISABLE KEYS */;
/*!40000 ALTER TABLE `complaint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dict_commission_rate`
--

DROP TABLE IF EXISTS `dict_commission_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_commission_rate` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `value` decimal(5,2) NOT NULL COMMENT '提成值 如 0.80',
  `label` varchar(20) NOT NULL COMMENT '标签 如 "八成"',
  `sort` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COMMENT='陪玩提成字典';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dict_commission_rate`
--

LOCK TABLES `dict_commission_rate` WRITE;
/*!40000 ALTER TABLE `dict_commission_rate` DISABLE KEYS */;
INSERT INTO `dict_commission_rate` VALUES (1,0.70,'七成',1,1),(2,0.80,'八成',2,1),(3,0.90,'九成',3,1);
/*!40000 ALTER TABLE `dict_commission_rate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dict_deposit`
--

DROP TABLE IF EXISTS `dict_deposit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_deposit` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `value` decimal(10,2) NOT NULL COMMENT '押金金额',
  `label` varchar(20) NOT NULL COMMENT '标签 如 "300押金"',
  `sort` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COMMENT='押金字典';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dict_deposit`
--

LOCK TABLES `dict_deposit` WRITE;
/*!40000 ALTER TABLE `dict_deposit` DISABLE KEYS */;
INSERT INTO `dict_deposit` VALUES (1,200.00,'200押金',1,1),(2,300.00,'300押金',2,1),(3,500.00,'500押金',3,1);
/*!40000 ALTER TABLE `dict_deposit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dict_discount`
--

DROP TABLE IF EXISTS `dict_discount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_discount` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `value` decimal(5,2) NOT NULL COMMENT '折扣值 如 0.90',
  `label` varchar(20) NOT NULL COMMENT '标签 如 "九折"',
  `sort` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COMMENT='折扣字典';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dict_discount`
--

LOCK TABLES `dict_discount` WRITE;
/*!40000 ALTER TABLE `dict_discount` DISABLE KEYS */;
INSERT INTO `dict_discount` VALUES (1,1.00,'无折扣',1,1),(2,0.95,'九五折',2,1),(3,0.90,'九折',3,1),(4,0.85,'八五折',4,1),(5,0.80,'八折',5,1),(6,0.75,'七五折',6,1),(7,0.70,'七折',7,1),(8,0.50,'五折',8,1);
/*!40000 ALTER TABLE `dict_discount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dict_extra_fee`
--

DROP TABLE IF EXISTS `dict_extra_fee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_extra_fee` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL COMMENT '费用名称',
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '金额',
  `sort` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COMMENT='附加费用字典';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dict_extra_fee`
--

LOCK TABLES `dict_extra_fee` WRITE;
/*!40000 ALTER TABLE `dict_extra_fee` DISABLE KEYS */;
INSERT INTO `dict_extra_fee` VALUES (1,'过年+10',10.00,1,1),(2,'1陪2+20',20.00,2,1),(3,'通宵+30',30.00,3,1);
/*!40000 ALTER TABLE `dict_extra_fee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dict_game_category`
--

DROP TABLE IF EXISTS `dict_game_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_game_category` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '类别名称',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1启用 0禁用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COMMENT='游戏类别字典';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dict_game_category`
--

LOCK TABLES `dict_game_category` WRITE;
/*!40000 ALTER TABLE `dict_game_category` DISABLE KEYS */;
INSERT INTO `dict_game_category` VALUES (1,'三角洲',1,1),(2,'瓦',2,1),(3,'英雄联盟',3,1),(4,'Steam',4,1);
/*!40000 ALTER TABLE `dict_game_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dict_game_item`
--

DROP TABLE IF EXISTS `dict_game_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_game_item` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `category_id` bigint(20) NOT NULL COMMENT '关联游戏类别ID',
  `name` varchar(50) NOT NULL COMMENT '项目名称',
  `default_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '默认单价',
  `sort` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_category_id` (`category_id`),
  CONSTRAINT `dict_game_item_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `dict_game_category` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COMMENT='游戏项目字典';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dict_game_item`
--

LOCK TABLES `dict_game_item` WRITE;
/*!40000 ALTER TABLE `dict_game_item` DISABLE KEYS */;
INSERT INTO `dict_game_item` VALUES (1,1,'三角洲-单排',40.00,1,1),(2,1,'三角洲-双排',35.00,2,1),(3,1,'三角洲-三排',30.00,3,1),(4,2,'瓦-单排',45.00,1,1),(5,2,'瓦-双排',40.00,2,1),(6,2,'瓦-三排',35.00,3,1),(7,3,'英雄联盟-单排',35.00,1,1),(8,3,'英雄联盟-双排',30.00,2,1),(9,4,'Steam-云游戏',50.00,1,1);
/*!40000 ALTER TABLE `dict_game_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(30) NOT NULL COMMENT '订单编号 YYYYMMDD+4位序号',
  `order_date` date NOT NULL COMMENT '订单日期',
  `cs_id` bigint(20) DEFAULT NULL COMMENT '客服ID',
  `boss_id` bigint(20) NOT NULL COMMENT '老板ID',
  `account_id` bigint(20) DEFAULT NULL COMMENT '账户ID',
  `companion_id` bigint(20) DEFAULT NULL COMMENT '陪玩ID',
  `game_category` varchar(30) DEFAULT NULL COMMENT '游戏类别',
  `game_item` varchar(50) DEFAULT NULL COMMENT '游戏项目',
  `unit_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '陪玩单价',
  `extra_fees` json DEFAULT NULL COMMENT '附加费用 [{"name":"过年+10","amount":10}]',
  `duration` decimal(5,1) NOT NULL DEFAULT '0.0' COMMENT '时长（支持0.5）',
  `discount` decimal(5,2) NOT NULL DEFAULT '1.00' COMMENT '折扣',
  `order_total` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '订单总计',
  `discounted_total` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '折后总计',
  `commission_rate` decimal(5,2) NOT NULL DEFAULT '0.80' COMMENT '陪玩提成率',
  `companion_income` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '陪玩收入',
  `shop_income` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '店内收入',
  `referrer_type` enum('companion','boss','none') NOT NULL DEFAULT 'none' COMMENT '推荐人类型',
  `referrer_id` bigint(20) DEFAULT NULL COMMENT '推荐人ID',
  `specific_time` varchar(50) DEFAULT NULL COMMENT '具体时间（陪玩填写）',
  `report_screenshot` varchar(255) DEFAULT NULL COMMENT '报单确认截图',
  `status` enum('dispatched','pending_confirm','confirmed','confirmed_error','settled','cancelled') NOT NULL DEFAULT 'dispatched' COMMENT '状态',
  `reject_reason` text COMMENT '驳回原因',
  `cs_remark` text COMMENT '客服备注',
  `source` enum('miniapp','cs_manual','renewal') NOT NULL DEFAULT 'cs_manual' COMMENT '来源',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`),
  KEY `idx_order_no` (`order_no`),
  KEY `idx_boss_id` (`boss_id`),
  KEY `idx_companion_id` (`companion_id`),
  KEY `idx_status` (`status`),
  KEY `idx_order_date` (`order_date`),
  CONSTRAINT `order_ibfk_1` FOREIGN KEY (`boss_id`) REFERENCES `boss` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recharge_record`
--

DROP TABLE IF EXISTS `recharge_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recharge_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `boss_id` bigint(20) NOT NULL COMMENT '老板ID',
  `account_id` bigint(20) DEFAULT NULL COMMENT '账户ID（散户时为null）',
  `type` enum('new_card','old_recharge','old_card') NOT NULL COMMENT '新客户开卡/老客户续存/老客户开卡',
  `account_type` enum('retail','silver','gold','diamond') DEFAULT NULL COMMENT '账户类型',
  `companion_id` bigint(20) DEFAULT NULL COMMENT '存单陪玩（店存时为null）',
  `discount` decimal(5,2) DEFAULT NULL COMMENT '折扣',
  `recharge_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '充值金额',
  `gift_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '赠送金额',
  `payment_method` set('alipay','wechat','other') DEFAULT NULL COMMENT '充值方式',
  `screenshot` varchar(255) DEFAULT NULL COMMENT '收款截图URL',
  `cs_id` bigint(20) DEFAULT NULL COMMENT '操作客服ID',
  `status` enum('pending','confirmed','cancelled') NOT NULL DEFAULT 'pending' COMMENT '状态',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_boss_id` (`boss_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `recharge_record_ibfk_1` FOREIGN KEY (`boss_id`) REFERENCES `boss` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='充值记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recharge_record`
--

LOCK TABLES `recharge_record` WRITE;
/*!40000 ALTER TABLE `recharge_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `recharge_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salary_settlement`
--

DROP TABLE IF EXISTS `salary_settlement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salary_settlement` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `companion_id` bigint(20) NOT NULL COMMENT '陪玩ID',
  `period_start` date NOT NULL COMMENT '结算周期开始',
  `period_end` date NOT NULL COMMENT '结算周期结束',
  `total_orders` int(11) NOT NULL DEFAULT '0' COMMENT '总单数',
  `total_income` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '总流水',
  `commission_rate_avg` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '平均提成率',
  `gross_salary` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '应发工资',
  `fines` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '罚款',
  `rewards` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '带新奖励',
  `net_salary` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '实发工资',
  `status` enum('pending','settled') NOT NULL DEFAULT 'pending' COMMENT '状态',
  `settled_at` datetime DEFAULT NULL COMMENT '结算时间',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_companion_id` (`companion_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `salary_settlement_ibfk_1` FOREIGN KEY (`companion_id`) REFERENCES `companion` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='工资结算表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salary_settlement`
--

LOCK TABLES `salary_settlement` WRITE;
/*!40000 ALTER TABLE `salary_settlement` DISABLE KEYS */;
/*!40000 ALTER TABLE `salary_settlement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_config`
--

DROP TABLE IF EXISTS `system_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `site_name` varchar(100) NOT NULL DEFAULT '电竞陪玩管理系统' COMMENT '站点名称',
  `site_title` varchar(100) NOT NULL DEFAULT '' COMMENT '主标题',
  `site_subtitle` varchar(200) NOT NULL DEFAULT '' COMMENT '副标题',
  `site_logo` varchar(255) NOT NULL DEFAULT '' COMMENT 'Logo图片URL',
  `custom_tags` json DEFAULT NULL COMMENT '自定义标签，最多5个',
  `welcome_message` text COMMENT '欢迎语',
  `copyright` varchar(200) NOT NULL DEFAULT '' COMMENT '版权声明',
  `icp_info` varchar(100) NOT NULL DEFAULT '' COMMENT '备案信息',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='系统配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_config`
--

LOCK TABLES `system_config` WRITE;
/*!40000 ALTER TABLE `system_config` DISABLE KEYS */;
INSERT INTO `system_config` VALUES (1,'电竞陪玩管理系统','','','',NULL,NULL,'','','2026-05-23 09:39:48','2026-05-23 09:39:48');
/*!40000 ALTER TABLE `system_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `withdraw_record`
--

DROP TABLE IF EXISTS `withdraw_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `withdraw_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `companion_id` bigint(20) NOT NULL COMMENT '陪玩ID',
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '提现金额',
  `alipay_account` varchar(50) NOT NULL DEFAULT '' COMMENT '支付宝账号',
  `alipay_name` varchar(50) NOT NULL DEFAULT '' COMMENT '支付宝实名',
  `status` enum('pending','approved','rejected','paid') NOT NULL DEFAULT 'pending' COMMENT '状态',
  `cs_id` bigint(20) DEFAULT NULL COMMENT '处理客服ID',
  `remark` text COMMENT '备注',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_companion_id` (`companion_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `withdraw_record_ibfk_1` FOREIGN KEY (`companion_id`) REFERENCES `companion` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='提现记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `withdraw_record`
--

LOCK TABLES `withdraw_record` WRITE;
/*!40000 ALTER TABLE `withdraw_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `withdraw_record` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-23 14:05:57
